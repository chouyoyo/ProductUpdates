(() => {
  'use strict';
  const root=document.getElementById('onebutton-desktop');
  const hero=document.getElementById('hero'),screen=document.getElementById('screen'),menu=document.getElementById('menu');
  let state={page:'welcome',bluetooth:{},release:{},choices:[],busy:false};
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const icon=name=>`<img src="icons/${name}.png" alt="" aria-hidden="true">`;
  const picture=(name,done=false)=>`<div class="pictogram${done?' done':''}">${icon(name)}</div>`;
  const primary=(label,action)=>`<button type="button" class="primary" data-action="${action}" ${state.busy?'disabled':''}><span>${label}</span><span class="arrow" aria-hidden="true">→</span></button>`;
  const secondary=(label,action)=>`<button type="button" class="text-button" data-action="${action}" ${state.busy?'disabled':''}>${label}</button>`;
  const name=()=>state.product==='bee'?'太空蜜蜂':'三合一';
  function feature(title,subtitle,image,action,main=false,id=''){
    return `<button type="button" class="feature${main?' feature-main':''}" data-action="${action}" data-id="${esc(id)}" ${state.busy?'disabled':''}><span class="feature-icon">${icon(image)}</span><span class="feature-content"><strong>${esc(title)}</strong><small>${esc(subtitle)}</small></span><span class="chevron" aria-hidden="true">›</span></button>`;
  }
  function send(action,extra={}){
    const handler=window.webkit?.messageHandlers?.onebutton;
    if(handler)handler.postMessage({action,...extra});
  }
  function render(incoming){
    state=incoming;const page=state.page,ble=state.bluetooth||{},release=state.release||{};
    const protectedPage=['identifying','checking','downloading','updating','resetting'].includes(page);
    const headers={
      welcome:['LET’S GET STARTED','连接你的\n游戏机。','通过 USB 连接电脑，自动识别你的游戏机。'],
      identifying:['FIND YOUR DEVICE','正在认识\n你的游戏机。','自动读取产品型号和版本，请保持连接。'],
      home:['YOUR DEVICE',name(),'选择你想使用的功能。'],
      choose:['SELECT A DEVICE','选择这次\n使用的游戏机。','同时发现多台支持的设备。'],
      disconnected:['USB CONNECTION','设备已断开。','重新接好 USB 后，会自动识别。'],
      unknown:['DEVICE NOT FOUND','暂时\n无法识别。','请确认连接的是支持的游戏机。'],
      checking:['CHECKING UPDATE','检查新版本。','只查找适用于当前游戏机的更新。'],
      update:['ONLINE UPDATE','发现新版本。','查看更新内容，准备好就开始。'],
      resetConfirm:['START FRESH','积分清零。','清除累计积分，重新开始。'],
      resetting:['START FRESH','正在清零。','请保持 USB 连接。'],
      resetSuccess:['ALL CLEAR','积分已清零。','重新开始，继续玩吧。'],
      resetUnavailable:['ONE MORE STEP','先更新游戏机。','新版游戏机程序支持积分清零。'],
      resetFailed:['LET’S TRY AGAIN','尚未确认清零。','重新识别游戏机后查看积分。'],
      latest:['UP TO DATE','暂无\n可用更新。','当前没有适用于这台游戏机的新版本。'],
      downloading:['ONLINE UPDATE','正在下载。','更新文件会自动验证，之后开始写入。'],
      updating:['UPDATING','好玩的，\n马上就来。','保持 USB 连接，不要操作电源。'],
      success:['ALL SET','更新完成。\n开玩吧。','已确认新版本启动，可以开始玩了。'],
      unconfirmed:['ONE MORE STEP','写入完成。\n等待确认启动。','目前还不能确认游戏机已正常启动。'],
      failed:['LET’S TRY AGAIN','更新\n尚未完成。','接好 USB 后重新检查，或查看帮助。'],
      network:['BACK ONLINE','暂时\n连不上。','检查网络后再试一次。'],
      bluetooth:['CONNECT & PLAY','蓝牙连接。\n即刻同步。','连接后，用电脑键盘控制游戏机。'],
      connected:['READY TO PLAY',ble.connected?'已连接。\n开始玩吧。':ble.nearbyCount>1?'发现多台\n太空蜜蜂。':'正在寻找\n太空蜜蜂。',ble.connected?'可以收起窗口，键盘同步会在后台继续。':'请保持游戏机开机，并切换到蓝牙模式。']
    };
    const h=headers[page]||headers.welcome;
    const back=!protectedPage&&!['welcome','disconnected'].includes(page)?'<button type="button" class="back" data-action="home" aria-label="返回游戏机">←</button>':'';
    hero.innerHTML=`<div class="hero-top">${back}<span class="eyebrow">${h[0]}</span></div><h2>${esc(h[1])}</h2><p>${esc(h[2])}</p><div class="brand-signature"><div class="brand-mark" aria-hidden="true">1</div><div class="brand-wordmark">ONE BUTTON</div><div class="brand-caption">MAKE TIME TO PLAY.</div></div>`;
    const menuButton=root.querySelector('.menu-button');menuButton.disabled=state.busy||state.flashing;menu.hidden=true;menuButton.setAttribute('aria-expanded','false');
    document.getElementById('reset-scores').hidden=state.product!=='bee'||!ble.resetReady;
    let content='';
    if(page==='welcome')content=`${picture('cable')}<h3>开始前，两步准备。</h3><div class="steps"><div class="step"><span class="step-number">1</span><span>关闭游戏机电源开关</span></div><div class="step"><span class="step-number">2</span><span>用数据线连接主板 USB-C 口<small>请使用数据口，不要连接充电口。</small></span></div></div><div class="bottom">${primary('OK，已连接','identify')}<details><summary>找不到数据口？</summary><p>请使用主板 USB-C 数据口。充电口无法传输数据，也不要同时连接两个 USB 口。</p></details></div>`;
    if(page==='identifying'||page==='checking')content=`${picture(page==='checking'?'download':'scan')}<h3 class="center">${page==='checking'?'正在检查在线版本':'正在识别游戏机'}</h3><p class="body-copy center">${page==='checking'?'请稍等，正在连接更新服务。':'不需要手动选择产品型号。'}</p><div class="wait-line" aria-hidden="true"><span></span></div>`;
    if(page==='home')content=`<div class="device" role="img" aria-label="游戏机示意图"><div class="device-display">${state.product==='bee'?'BEE FIGHTER':'3 IN 1'}</div><div class="device-key"></div></div><div class="status"><span class="dot"></span>${state.usb?'USB 已连接':ble.connected?'蓝牙已连接':'游戏机已识别'}</div>${state.product==='bee'?feature('蓝牙连接',ble.connected?'查看键盘同步状态':'连接游戏机，开启键盘同步','bluetooth','bluetooth',true):''}${feature('在线升级','检查游戏机的新版本','download','check',state.product!=='bee')}${state.product==='parade'?feature('积分清零','清除三款游戏共用的累计积分','refresh','resetPoints'):''}`;
    if(page==='resetConfirm')content=`${picture('refresh')}<h3>确定将积分清零？</h3><p class="body-copy">三款游戏共用的累计积分将归零，无法撤销。<br>已记忆的游戏场景会保留。</p><p class="safety">当前积分 <strong>${esc(state.score??'—')}</strong></p><div class="bottom">${primary('确认清零','confirmResetPoints')}${secondary('取消','home')}</div>`;
    if(page==='resetting')content=`${picture('refresh')}<h3 class="center">正在清零积分</h3><p class="body-copy center">请保持连接，等待结果。</p><div class="wait-line" aria-hidden="true"><span></span></div>`;
    if(page==='resetSuccess')content=`${picture('check',true)}<h3 class="center">积分已清零</h3><p class="body-copy center">现在可以从零开始。<br>游戏机已回到待机画面。</p><div class="bottom">${primary('完成','home')}</div>`;
    if(page==='resetUnavailable')content=`${picture('download')}<h3>更新后即可清零。</h3><p class="body-copy">请先将游戏机更新至 1.7.2 或更新版本。</p><div class="bottom">${primary('检查在线更新','check')}${secondary('返回游戏机','home')}</div>`;
    if(page==='resetFailed')content=`${picture('warning')}<h3>请先确认当前积分。</h3><p class="body-copy">${esc(state.error||'未收到清零确认，请重新识别游戏机后查看。')}</p><div class="bottom">${primary('重新识别','identify')}${secondary('返回游戏机','home')}</div>`;
    if(page==='choose')content=`<h3>选择你的游戏机。</h3><p class="body-copy" style="margin-bottom:24px">请选择本次要操作的一台。</p><div class="choose-list">${(state.choices||[]).map((c,i)=>feature(c.product==='bee'?'太空蜜蜂':'三合一',c.suffix?`设备尾号 ${c.suffix}`:`游戏机 ${i+1}`,'gamepad','choose',i===0,c.id)).join('')}</div>`;
    if(page==='update')content=`<div class="version"><div><small>当前版本</small>${esc(state.version)}</div><span aria-hidden="true">→</span><div><small>新版本</small>${esc(release.version)}</div></div><p class="notes-title">这次更新</p><p class="release-notes">${esc(release.release_notes||'优化游戏体验。')}</p><p class="safety">保持 USB 连接，升级过程中不要操作电源。</p><div class="bottom">${primary('开始更新','upgrade')}${secondary('稍后再说','home')}</div>`;
    if(page==='latest')content=`${picture('check',true)}<h3 class="center">当前版本 ${esc(state.version)}</h3><p class="body-copy center">有适用的新版本时，会在这里显示。</p><div class="bottom">${primary('返回游戏机','home')}</div>`;
    if(page==='downloading'||page==='updating'){
      const downloading=page==='downloading',progress=Math.round(Math.min(1,Math.max(0,Number(state.progress)||0))*100);
      const stage=downloading?'下载并验证更新':progress>=90?'重启并确认启动':'写入游戏机';
      content=`${picture('download')}<h3>${downloading?'正在下载更新':'正在更新游戏机'}</h3><p class="body-copy">${downloading?'验证通过后会自动开始写入。':'请保持连接，等待完成提示。'}</p><div class="progress-top"><span>${esc(stage)}</span><span>${downloading?'':progress+'%'}</span></div><div class="track${downloading?' indeterminate':''}" role="progressbar" aria-label="游戏机更新进度" ${downloading?'':`aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"`}><div class="bar" style="width:${downloading?35:progress}%"></div></div><div class="progress-steps"><div class="progress-row">${downloading?'◉':'✓'}　下载并验证更新</div><div class="progress-row">${!downloading&&progress<90?'◉':'○'}　写入游戏机</div><div class="progress-row">${!downloading&&progress>=90?'◉':'○'}　重启并确认启动</div></div>`;
    }
    if(page==='success')content=`${picture('check',true)}<h3 class="center">${name()} · ${esc(state.version)}</h3><p class="body-copy center">新版本已启动。<br>现在可以拔下 USB，打开游戏机。</p><div class="bottom">${primary('完成','home')}</div>`;
    if(page==='unconfirmed')content=`${picture('refresh')}<h3>已写入，尚未确认启动。</h3><p class="body-copy">请保持连接，重新识别并读取版本。若无法识别，可拔下 USB 后重新上电检查游戏机屏幕。</p><div class="bottom">${primary('重新识别并确认','identify')}</div>`;
    if(page==='bluetooth')content=`${picture('bluetooth')}<h3>切换到蓝牙模式。</h3><div class="steps"><div class="step"><span class="step-number">1</span><span>拔下 USB，打开游戏机电源</span></div><div class="step"><span class="step-number">2</span><span>长按游戏机按键<small>切换到蓝牙模式后继续。</small></span></div></div>${state.error?`<p class="error-inline">${esc(state.error)}</p>`:''}<div class="bottom">${primary('开始连接','connect')}</div>`;
    if(page==='connected'){
      const denied=Number(ble.authorization)===1||Number(ble.authorization)===2;
      if(denied)content=`${picture('bluetooth')}<h3>允许蓝牙访问。</h3><p class="body-copy">在系统设置中允许“一个按键”访问蓝牙，然后回来继续。</p><div class="bottom">${primary('打开蓝牙权限设置','bluetoothSettings')}${secondary('返回游戏机','home')}</div>`;
      else if(ble.poweredOff)content=`${picture('bluetooth')}<h3>请开启 Mac 蓝牙。</h3><p class="body-copy">开启后会自动寻找游戏机。</p><div class="bottom">${secondary('返回游戏机','home')}</div>`;
      else if(ble.nearbyCount>1)content=`${picture('bluetooth')}<h3>请只开启目标游戏机。</h3><p class="body-copy">附近发现多台太空蜜蜂。关闭其他机器后，再重新寻找。</p><div class="bottom">${primary('重新寻找','connect')}${secondary('返回游戏机','home')}</div>`;
      else if(!ble.connected)content=`${picture('bluetooth')}<h3 class="center">正在连接太空蜜蜂</h3><p class="body-copy center">确认游戏机处于蓝牙模式。<br>首次使用时，请允许系统的蓝牙请求。</p><div class="wait-line" aria-hidden="true"><span></span></div><div class="bottom">${secondary('返回游戏机','home')}</div>`;
      else if(!ble.inputReady)content=`${picture('keyboard')}<h3>开启键盘输入权限。</h3><p class="body-copy">蓝牙已经连接。请允许输入监控权限，让电脑按键同步到游戏机。</p><div class="bottom">${primary('开启键盘输入权限','permissions')}${secondary('暂不开启','home')}</div>`;
      else content=`${picture('keyboard',true)}<h3 class="center">键盘同步${ble.sync?'已开启':'已暂停'}</h3><p class="body-copy center">${ble.sync?'按下电脑键盘，游戏机就会响应。<br>可以收起窗口，继续使用电脑。':'蓝牙保持连接，按键暂不发送。'}</p><div class="bottom">${primary(ble.sync?'暂停同步':'开启同步','sync')}${secondary('返回游戏机','home')}</div>`;
    }
    if(page==='disconnected')content=`${picture('unplug')}<h3>接上 USB 即可继续。</h3><p class="body-copy">关闭电源开关，用数据线接回主板 USB-C 数据口。插入设备后会自动重新识别。</p><div class="bottom">${primary('重新检查连接','identify')}</div>`;
    if(page==='unknown')content=`${picture('help')}<h3>没有识别到支持的游戏机。</h3><p class="body-copy">确认数据线和接口正确，并关闭占用设备的串口工具。</p><details><summary>旧版设备怎么办？</summary><p>部分旧固件没有产品标识，需要联系作者完成一次首次接入。为避免刷错设备，无法手动指定型号。</p></details><div class="bottom">${primary('重新识别','identify')}</div>`;
    if(page==='network')content=`${picture('network')}<h3>暂时无法获取更新。</h3><p class="body-copy">请检查网络，或稍后再试。当前没有写入新的游戏内容。</p><details><summary>查看原因</summary><p>${esc(state.error||'更新服务暂不可用，请稍后重试。')}</p></details><div class="bottom">${primary('重试','check')}${secondary('返回游戏机','home')}</div>`;
    if(page==='failed')content=`${picture('warning')}<h3>请保持 USB 连接。</h3><p class="body-copy">重新识别设备后检查更新。若无法识别，请查看原因并联系作者。</p><details><summary>查看原因</summary><p>${esc(state.error||'设备未确认更新完成。')}</p></details><div class="bottom">${primary('重新识别设备','identify')}${secondary('查看诊断记录','diagnostics')}</div>`;
    screen.innerHTML=content;
  }
  root.addEventListener('click',event=>{
    const button=event.target.closest('button[data-action]');if(!button||button.disabled)return;
    const action=button.dataset.action;
    if(action==='menu'){menu.hidden=!menu.hidden;button.setAttribute('aria-expanded',String(!menu.hidden));return;}
    menu.hidden=true;
    if(action==='choose')send(action,{id:button.dataset.id});else send(action);
  });
  document.addEventListener('keydown',event=>{if(event.key==='Escape')menu.hidden=true;});
  window.OneButton={render};render(state);
})();
